# plate_food > 2023-10-18 10:16am
https://universe.roboflow.com/subhash-pathirana-cdryb/plate_food

Provided by a Roboflow user
License: CC BY 4.0

